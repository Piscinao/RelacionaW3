﻿using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;
using JWTDemo.Data;
using JWTDemo.Model;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;

namespace JWTDemo.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthController : ControllerBase
    {
        private readonly UserManager<ApplicationUser> _userManager;

        public AuthController(UserManager<ApplicationUser> userManager)
        {
            _userManager = userManager;
        }

        [Route("insertuser")]
        [HttpPost]
        public async Task<ActionResult> InsertUser()
        {
            var user = new ApplicationUser
            {
                UserName = "test",
                Email = "info@info.com",
                SecurityStamp = Guid.NewGuid().ToString()
            };
            var result = await _userManager.CreateAsync(user, "123456");
            if (result.Succeeded)
            {
                await _userManager.AddToRoleAsync(user, "Customer");
                var mobileNoClaim = new Claim("MobileNo", "111111111", ClaimValueTypes.String);
            }
            return Ok(
                new
                {
                    Username = user.UserName,
                    Password = "123456"
                });
        }


        [Route("login")]
        [HttpPost]
        public async Task<ActionResult> Login([FromBody] Login model)
        {
            var user = await _userManager.FindByNameAsync(model.Username);
            if (user != null && await _userManager.CheckPasswordAsync(user, model.Password))
            {
                var claim = new[]
                {
                    new Claim(JwtRegisteredClaimNames.Sub, user.UserName)
                };
                var signinKey = new SymmetricSecurityKey(
                    Encoding.UTF8.GetBytes("MySuperSecureKey"));

                var token = new JwtSecurityToken(
                    issuer: "http://xyz.com",
                    audience: "http://xyz.com",
                    expires: DateTime.UtcNow.AddHours(1),
                    signingCredentials: new SigningCredentials(signinKey, SecurityAlgorithms.HmacSha256)
                    );

                return Ok(
                    new
                    {
                        token = new JwtSecurityTokenHandler().WriteToken(token),
                        expiration=token.ValidTo
                    });
            }
            return Unauthorized();
        }
}
}